# Items in the misc directory
- arima_model.zip

## arima_model.zip
This is the zipped *ARIMA* model that we trained in the [Time Series Modeling](../code/06%20-%20Time%20Series%20Modeling.ipynb) notebook located in code directory. 
It is saved in the pickle format inside of the zipped format.
The model is used to predict the future values of the time series data, specifically the future daily number of sales of cars.
